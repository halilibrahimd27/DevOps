--
-- PostgreSQL database cluster dump
--

\restrict XmhPPJuaOCoedK18Ufx3gf2vI2pNV5Ati9foxLp4LlOhbguKybLrOii27mj4b5D

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE root;
ALTER ROLE root WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:smSz9m7GQHAkekLc08sc8w==$EwiwtvXWtqLDY5h1VzXVNxOfit5HhggfHub6gadmqdw=:ZU8I6cmx95++qWsCqyVAUEqrReH8KL9MuyvMUyyRNlk=';

--
-- User Configurations
--








\unrestrict XmhPPJuaOCoedK18Ufx3gf2vI2pNV5Ati9foxLp4LlOhbguKybLrOii27mj4b5D

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict eHjcPv5Dl3eK1DrflRNDV76Q73un1qknoUavjXsIs1SNIoI8cNCLjI41RPDWC3K

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict eHjcPv5Dl3eK1DrflRNDV76Q73un1qknoUavjXsIs1SNIoI8cNCLjI41RPDWC3K

--
-- Database "defaultdb" dump
--

--
-- PostgreSQL database dump
--

\restrict 4CSLyMqQLSYrXxZgriL6pKHkw5eEGY1fVtdgLduqCcknZrcUTBNcrdf7TekyEjw

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: defaultdb; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE defaultdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE defaultdb OWNER TO root;

\unrestrict 4CSLyMqQLSYrXxZgriL6pKHkw5eEGY1fVtdgLduqCcknZrcUTBNcrdf7TekyEjw
\connect defaultdb
\restrict 4CSLyMqQLSYrXxZgriL6pKHkw5eEGY1fVtdgLduqCcknZrcUTBNcrdf7TekyEjw

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict 4CSLyMqQLSYrXxZgriL6pKHkw5eEGY1fVtdgLduqCcknZrcUTBNcrdf7TekyEjw

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict xyxypXHdq5ogcIw9COkTY5iVVsdNf972VXUdR6aGodLW3wNVblO6WN6K87mhrcG

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict xyxypXHdq5ogcIw9COkTY5iVVsdNf972VXUdR6aGodLW3wNVblO6WN6K87mhrcG

--
-- PostgreSQL database cluster dump complete
--

