--
-- PostgreSQL database cluster dump
--

\restrict 63jlFch0ucjLR6IOPuQwlOEJBCq3PK8mIU1uk25M9EJfZe21eVhSj5NyFi1hudh

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE root;
ALTER ROLE root WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:smSz9m7GQHAkekLc08sc8w==$EwiwtvXWtqLDY5h1VzXVNxOfit5HhggfHub6gadmqdw=:ZU8I6cmx95++qWsCqyVAUEqrReH8KL9MuyvMUyyRNlk=';

--
-- User Configurations
--








\unrestrict 63jlFch0ucjLR6IOPuQwlOEJBCq3PK8mIU1uk25M9EJfZe21eVhSj5NyFi1hudh

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict ByamZ8FUp6Ef0vtTOUUKSePEMWNeH4nOI9f1ftjSC8MDcP39CertT0i4anniavH

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict ByamZ8FUp6Ef0vtTOUUKSePEMWNeH4nOI9f1ftjSC8MDcP39CertT0i4anniavH

--
-- Database "defaultdb" dump
--

--
-- PostgreSQL database dump
--

\restrict mwg4us2nE9rhFnpIx0cQPUWUUIWAzVUfCrc5Q2oBXH2NQmwwUMrgaXUGO1kfELG

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: defaultdb; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE defaultdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE defaultdb OWNER TO root;

\unrestrict mwg4us2nE9rhFnpIx0cQPUWUUIWAzVUfCrc5Q2oBXH2NQmwwUMrgaXUGO1kfELG
\connect defaultdb
\restrict mwg4us2nE9rhFnpIx0cQPUWUUIWAzVUfCrc5Q2oBXH2NQmwwUMrgaXUGO1kfELG

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict mwg4us2nE9rhFnpIx0cQPUWUUIWAzVUfCrc5Q2oBXH2NQmwwUMrgaXUGO1kfELG

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict 3wR5hmWMMWYX8EuehECng6BhGszD3bZ6HMT72hS9BuelXwhMsw2f7TJOY39sA5q

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict 3wR5hmWMMWYX8EuehECng6BhGszD3bZ6HMT72hS9BuelXwhMsw2f7TJOY39sA5q

--
-- PostgreSQL database cluster dump complete
--

