--
-- PostgreSQL database cluster dump
--

\restrict af3WGRi3299Kdbbt5gjKepzIAcFMNrypDYbzk8h0Iw4eVfZHZOUrTUDfl5fql5l

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE root;
ALTER ROLE root WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:smSz9m7GQHAkekLc08sc8w==$EwiwtvXWtqLDY5h1VzXVNxOfit5HhggfHub6gadmqdw=:ZU8I6cmx95++qWsCqyVAUEqrReH8KL9MuyvMUyyRNlk=';

--
-- User Configurations
--








\unrestrict af3WGRi3299Kdbbt5gjKepzIAcFMNrypDYbzk8h0Iw4eVfZHZOUrTUDfl5fql5l

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict bGT7nC0b6MDDSraobqf4wgG7apE2Uk4L2b8CseAbNYnGm9oDaLwrzBIdsZgjwRv

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict bGT7nC0b6MDDSraobqf4wgG7apE2Uk4L2b8CseAbNYnGm9oDaLwrzBIdsZgjwRv

--
-- Database "defaultdb" dump
--

--
-- PostgreSQL database dump
--

\restrict CgEqVzBogSKh2zTKYwTfHfYHGzjny7a6sj8ficLC0knlmO6D31L7mBAGLNjbOnT

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: defaultdb; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE defaultdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE defaultdb OWNER TO root;

\unrestrict CgEqVzBogSKh2zTKYwTfHfYHGzjny7a6sj8ficLC0knlmO6D31L7mBAGLNjbOnT
\connect defaultdb
\restrict CgEqVzBogSKh2zTKYwTfHfYHGzjny7a6sj8ficLC0knlmO6D31L7mBAGLNjbOnT

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict CgEqVzBogSKh2zTKYwTfHfYHGzjny7a6sj8ficLC0knlmO6D31L7mBAGLNjbOnT

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict 9UMTXgynvoDcaz4qAbcGWOYS1FKZ6sJRt5TGPyFc2J649HIofjTQWNdFdZZnHZX

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict 9UMTXgynvoDcaz4qAbcGWOYS1FKZ6sJRt5TGPyFc2J649HIofjTQWNdFdZZnHZX

--
-- PostgreSQL database cluster dump complete
--

