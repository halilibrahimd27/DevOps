--
-- PostgreSQL database cluster dump
--

\restrict AQgygaf8LN3xFx2687bn3wFpwyvdfdtpIeKUJMizoh1oM8TiHDY6QakV7goO3aP

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE root;
ALTER ROLE root WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:smSz9m7GQHAkekLc08sc8w==$EwiwtvXWtqLDY5h1VzXVNxOfit5HhggfHub6gadmqdw=:ZU8I6cmx95++qWsCqyVAUEqrReH8KL9MuyvMUyyRNlk=';

--
-- User Configurations
--








\unrestrict AQgygaf8LN3xFx2687bn3wFpwyvdfdtpIeKUJMizoh1oM8TiHDY6QakV7goO3aP

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict NDRzfWRi6tAycJjQsQhXaMeCDcYpr38E6wP6XkZ700wGRon9b1NyVDuTRodJNsM

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict NDRzfWRi6tAycJjQsQhXaMeCDcYpr38E6wP6XkZ700wGRon9b1NyVDuTRodJNsM

--
-- Database "defaultdb" dump
--

--
-- PostgreSQL database dump
--

\restrict B7cD7QP4XACWtMx5vqn1AupIXEgPtE3NjfZUVG3CRzviJS7OSedSMcDoccSklX4

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: defaultdb; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE defaultdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE defaultdb OWNER TO root;

\unrestrict B7cD7QP4XACWtMx5vqn1AupIXEgPtE3NjfZUVG3CRzviJS7OSedSMcDoccSklX4
\connect defaultdb
\restrict B7cD7QP4XACWtMx5vqn1AupIXEgPtE3NjfZUVG3CRzviJS7OSedSMcDoccSklX4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict B7cD7QP4XACWtMx5vqn1AupIXEgPtE3NjfZUVG3CRzviJS7OSedSMcDoccSklX4

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict NpgeeIjGwBtoekbpH4vPUOIdgOLJ72FsYSt26dyOLebaz3Sbnm7u8i4mmnVRWdJ

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict NpgeeIjGwBtoekbpH4vPUOIdgOLJ72FsYSt26dyOLebaz3Sbnm7u8i4mmnVRWdJ

--
-- PostgreSQL database cluster dump complete
--

