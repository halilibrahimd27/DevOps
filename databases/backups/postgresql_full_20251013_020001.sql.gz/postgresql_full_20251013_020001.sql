--
-- PostgreSQL database cluster dump
--

\restrict gvrekuSbpSNILTF54pZxz0bM9OFrCYWeDNbg1jDWRYTLnnCE1wDhWyZgcFOS5lt

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE root;
ALTER ROLE root WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:roEld3x8TuQ8bSi9KhPKJg==$lbYxIGb9YGRy9bON1ZkblBILRYXGVLqsvvDpufP9gKs=:4x/aalULpsoxQH/UnzLnuAPdiu2pm/yFx8m47dvzm9A=';

--
-- User Configurations
--








\unrestrict gvrekuSbpSNILTF54pZxz0bM9OFrCYWeDNbg1jDWRYTLnnCE1wDhWyZgcFOS5lt

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict Iemkyh46ld1Raicqa29JfivgrmRP3l4QaxuNvKcfsVdDUWHIEa3S4ZriwWn1Ecp

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict Iemkyh46ld1Raicqa29JfivgrmRP3l4QaxuNvKcfsVdDUWHIEa3S4ZriwWn1Ecp

--
-- Database "defaultdb" dump
--

--
-- PostgreSQL database dump
--

\restrict pNFfaITyu6CzMr6yDoY0R5hpn2YfdalOYiZzpGUG1ioLdT1SFIUerPbHieFGndp

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: defaultdb; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE defaultdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE defaultdb OWNER TO root;

\unrestrict pNFfaITyu6CzMr6yDoY0R5hpn2YfdalOYiZzpGUG1ioLdT1SFIUerPbHieFGndp
\connect defaultdb
\restrict pNFfaITyu6CzMr6yDoY0R5hpn2YfdalOYiZzpGUG1ioLdT1SFIUerPbHieFGndp

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict pNFfaITyu6CzMr6yDoY0R5hpn2YfdalOYiZzpGUG1ioLdT1SFIUerPbHieFGndp

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict PaV6JKc9DyMYivLe7gOFc31svXCjanaE85DshDvhskq2ViCg3yfBzyIpzZVRBn9

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict PaV6JKc9DyMYivLe7gOFc31svXCjanaE85DshDvhskq2ViCg3yfBzyIpzZVRBn9

--
-- PostgreSQL database cluster dump complete
--

