--
-- PostgreSQL database cluster dump
--

\restrict gWyYFNZXSKSfUnuZOVyaJLEKrsGIAALIO0tqBNfRH33PyrqDB3m5u56UFaMqi2x

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE root;
ALTER ROLE root WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:roEld3x8TuQ8bSi9KhPKJg==$lbYxIGb9YGRy9bON1ZkblBILRYXGVLqsvvDpufP9gKs=:4x/aalULpsoxQH/UnzLnuAPdiu2pm/yFx8m47dvzm9A=';

--
-- User Configurations
--








\unrestrict gWyYFNZXSKSfUnuZOVyaJLEKrsGIAALIO0tqBNfRH33PyrqDB3m5u56UFaMqi2x

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict s7xEjqPXy2yjozkq7EdasdbTvM73NWsILTRfhkBSJ7YXUhPDHG00pqWjhPSeEfu

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict s7xEjqPXy2yjozkq7EdasdbTvM73NWsILTRfhkBSJ7YXUhPDHG00pqWjhPSeEfu

--
-- Database "defaultdb" dump
--

--
-- PostgreSQL database dump
--

\restrict q3GsfALZMlFDxEx3OJL4F7xINPFqzvdxQ9jPjxqaezAt1RZfob8869lwNDhMchc

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: defaultdb; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE defaultdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE defaultdb OWNER TO root;

\unrestrict q3GsfALZMlFDxEx3OJL4F7xINPFqzvdxQ9jPjxqaezAt1RZfob8869lwNDhMchc
\connect defaultdb
\restrict q3GsfALZMlFDxEx3OJL4F7xINPFqzvdxQ9jPjxqaezAt1RZfob8869lwNDhMchc

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict q3GsfALZMlFDxEx3OJL4F7xINPFqzvdxQ9jPjxqaezAt1RZfob8869lwNDhMchc

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict y2MOI31tgCKKrzSVaHcaX18huxBufq7k3QirvbA80cAjWNz6104uWFGQO62hie1

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict y2MOI31tgCKKrzSVaHcaX18huxBufq7k3QirvbA80cAjWNz6104uWFGQO62hie1

--
-- PostgreSQL database cluster dump complete
--

