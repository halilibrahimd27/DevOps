--
-- PostgreSQL database cluster dump
--

\restrict HoH3Y5DIhkmNf6VCG9gGbzUFybrrARmLnS3RyDBRhrRYShfp3LnNWaJKT2SI4TB

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE root;
ALTER ROLE root WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:smSz9m7GQHAkekLc08sc8w==$EwiwtvXWtqLDY5h1VzXVNxOfit5HhggfHub6gadmqdw=:ZU8I6cmx95++qWsCqyVAUEqrReH8KL9MuyvMUyyRNlk=';

--
-- User Configurations
--








\unrestrict HoH3Y5DIhkmNf6VCG9gGbzUFybrrARmLnS3RyDBRhrRYShfp3LnNWaJKT2SI4TB

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict vsNNpLVGPNxR7nyvxOp0U0hgPezzSHXgK9DkOfnSB6F432YjqiIWmWAiuHsTndG

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict vsNNpLVGPNxR7nyvxOp0U0hgPezzSHXgK9DkOfnSB6F432YjqiIWmWAiuHsTndG

--
-- Database "defaultdb" dump
--

--
-- PostgreSQL database dump
--

\restrict vCCtJDtaLAMf2QfbUOsyp5jeJB84OrrkwnM6Cc3wgRsahZdD1OUCiv4vWuOdK5z

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: defaultdb; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE defaultdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE defaultdb OWNER TO root;

\unrestrict vCCtJDtaLAMf2QfbUOsyp5jeJB84OrrkwnM6Cc3wgRsahZdD1OUCiv4vWuOdK5z
\connect defaultdb
\restrict vCCtJDtaLAMf2QfbUOsyp5jeJB84OrrkwnM6Cc3wgRsahZdD1OUCiv4vWuOdK5z

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict vCCtJDtaLAMf2QfbUOsyp5jeJB84OrrkwnM6Cc3wgRsahZdD1OUCiv4vWuOdK5z

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict QezCagVikqEwJhpm4nAtiXk346TWO3KF8xHghUoFjI9bEaPD3lbr2vKLCp9W1iy

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict QezCagVikqEwJhpm4nAtiXk346TWO3KF8xHghUoFjI9bEaPD3lbr2vKLCp9W1iy

--
-- PostgreSQL database cluster dump complete
--

