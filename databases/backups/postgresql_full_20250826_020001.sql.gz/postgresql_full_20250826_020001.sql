--
-- PostgreSQL database cluster dump
--

\restrict TsK2xxa5KPf5rUkM9SfasyULjS71qrQ45eid6C1jUNbj1Ny71KSMPD5fIH7VPBU

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE root;
ALTER ROLE root WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:smSz9m7GQHAkekLc08sc8w==$EwiwtvXWtqLDY5h1VzXVNxOfit5HhggfHub6gadmqdw=:ZU8I6cmx95++qWsCqyVAUEqrReH8KL9MuyvMUyyRNlk=';

--
-- User Configurations
--








\unrestrict TsK2xxa5KPf5rUkM9SfasyULjS71qrQ45eid6C1jUNbj1Ny71KSMPD5fIH7VPBU

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict duKp7zOHAEgJas7T1gbQjpIb0G7b4bqZHHN3eIOB2q7Kww0JqskNlc774TsaxoH

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict duKp7zOHAEgJas7T1gbQjpIb0G7b4bqZHHN3eIOB2q7Kww0JqskNlc774TsaxoH

--
-- Database "defaultdb" dump
--

--
-- PostgreSQL database dump
--

\restrict HopWkbJ3atot1aiak5cuFTMtgIilNlblMIEFwIDZn1dxocA8fkiUNTGV07k9Uzc

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: defaultdb; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE defaultdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE defaultdb OWNER TO root;

\unrestrict HopWkbJ3atot1aiak5cuFTMtgIilNlblMIEFwIDZn1dxocA8fkiUNTGV07k9Uzc
\connect defaultdb
\restrict HopWkbJ3atot1aiak5cuFTMtgIilNlblMIEFwIDZn1dxocA8fkiUNTGV07k9Uzc

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict HopWkbJ3atot1aiak5cuFTMtgIilNlblMIEFwIDZn1dxocA8fkiUNTGV07k9Uzc

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict 2cKQXpAJmvwU9wfRifYdyIOIwfxK8HR8fQKl2YO7tg2wcNre5uIZgJ4KLWRXsuu

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict 2cKQXpAJmvwU9wfRifYdyIOIwfxK8HR8fQKl2YO7tg2wcNre5uIZgJ4KLWRXsuu

--
-- PostgreSQL database cluster dump complete
--

