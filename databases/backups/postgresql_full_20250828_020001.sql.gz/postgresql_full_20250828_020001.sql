--
-- PostgreSQL database cluster dump
--

\restrict sfhDzv46SKkqEWbclkxZrEuZv7Z0L43lR63P8mhzqHR7f4Tfg0sbIkwOj0Lclgt

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE root;
ALTER ROLE root WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:smSz9m7GQHAkekLc08sc8w==$EwiwtvXWtqLDY5h1VzXVNxOfit5HhggfHub6gadmqdw=:ZU8I6cmx95++qWsCqyVAUEqrReH8KL9MuyvMUyyRNlk=';

--
-- User Configurations
--








\unrestrict sfhDzv46SKkqEWbclkxZrEuZv7Z0L43lR63P8mhzqHR7f4Tfg0sbIkwOj0Lclgt

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict YCVRS5Ac3hRWBPIYPR54T494CUdN8otJckW2c6W8niOsXnCYZb5ntVufmhIrC2O

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict YCVRS5Ac3hRWBPIYPR54T494CUdN8otJckW2c6W8niOsXnCYZb5ntVufmhIrC2O

--
-- Database "defaultdb" dump
--

--
-- PostgreSQL database dump
--

\restrict mVJjof78fOn99irF7XzpCgoyplhmOd2HadaQ7hiPX12wG5Cc2kX3994j4dOhxTK

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: defaultdb; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE defaultdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE defaultdb OWNER TO root;

\unrestrict mVJjof78fOn99irF7XzpCgoyplhmOd2HadaQ7hiPX12wG5Cc2kX3994j4dOhxTK
\connect defaultdb
\restrict mVJjof78fOn99irF7XzpCgoyplhmOd2HadaQ7hiPX12wG5Cc2kX3994j4dOhxTK

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict mVJjof78fOn99irF7XzpCgoyplhmOd2HadaQ7hiPX12wG5Cc2kX3994j4dOhxTK

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict BKekgOcLjigS5Ri05yyZyS1AJwq15N5A4IdbMo9X8IoVVE43ajJFKPFbubmOYqz

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict BKekgOcLjigS5Ri05yyZyS1AJwq15N5A4IdbMo9X8IoVVE43ajJFKPFbubmOYqz

--
-- PostgreSQL database cluster dump complete
--

