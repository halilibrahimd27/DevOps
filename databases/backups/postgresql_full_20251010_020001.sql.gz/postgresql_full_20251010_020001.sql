--
-- PostgreSQL database cluster dump
--

\restrict J1pWZrNci4qJoaUSWOM2SYcKehvmHVfRyBtaqghRkL0s4LERvj1qbaUbPZzDL0z

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE root;
ALTER ROLE root WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:roEld3x8TuQ8bSi9KhPKJg==$lbYxIGb9YGRy9bON1ZkblBILRYXGVLqsvvDpufP9gKs=:4x/aalULpsoxQH/UnzLnuAPdiu2pm/yFx8m47dvzm9A=';

--
-- User Configurations
--








\unrestrict J1pWZrNci4qJoaUSWOM2SYcKehvmHVfRyBtaqghRkL0s4LERvj1qbaUbPZzDL0z

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict DhrsXcvOAbXsSJPWenPlUxCYYaEobdazocbQenabwGnqtP1n2Pehpq0uHZyqpHV

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict DhrsXcvOAbXsSJPWenPlUxCYYaEobdazocbQenabwGnqtP1n2Pehpq0uHZyqpHV

--
-- Database "defaultdb" dump
--

--
-- PostgreSQL database dump
--

\restrict muazeHmtwFCwDCDPjnWKiRnVj4xzmJIT52rKEPrnIQ3Bg4V4Jz8J9xkJAJHk8ub

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: defaultdb; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE defaultdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE defaultdb OWNER TO root;

\unrestrict muazeHmtwFCwDCDPjnWKiRnVj4xzmJIT52rKEPrnIQ3Bg4V4Jz8J9xkJAJHk8ub
\connect defaultdb
\restrict muazeHmtwFCwDCDPjnWKiRnVj4xzmJIT52rKEPrnIQ3Bg4V4Jz8J9xkJAJHk8ub

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict muazeHmtwFCwDCDPjnWKiRnVj4xzmJIT52rKEPrnIQ3Bg4V4Jz8J9xkJAJHk8ub

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict DRMGgLUNcpgm3DOW0ROP2SetuMKzNtFzjnBmOhanwNNf4lrQP2UsgqiWwj4chGh

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict DRMGgLUNcpgm3DOW0ROP2SetuMKzNtFzjnBmOhanwNNf4lrQP2UsgqiWwj4chGh

--
-- PostgreSQL database cluster dump complete
--

