--
-- PostgreSQL database cluster dump
--

\restrict xBAtyvap1plaOTWDdrqXB5bOIVxl2xhK7HCE0rVSdIak9HG5j45ungftPCiYOFo

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE root;
ALTER ROLE root WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:smSz9m7GQHAkekLc08sc8w==$EwiwtvXWtqLDY5h1VzXVNxOfit5HhggfHub6gadmqdw=:ZU8I6cmx95++qWsCqyVAUEqrReH8KL9MuyvMUyyRNlk=';

--
-- User Configurations
--








\unrestrict xBAtyvap1plaOTWDdrqXB5bOIVxl2xhK7HCE0rVSdIak9HG5j45ungftPCiYOFo

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict PhgJWrVKhCJ3Udj7LEOsU4XzVXw4i7MHwizJUwfYgHD7q8N9mfFWIjutMzUNVIw

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict PhgJWrVKhCJ3Udj7LEOsU4XzVXw4i7MHwizJUwfYgHD7q8N9mfFWIjutMzUNVIw

--
-- Database "defaultdb" dump
--

--
-- PostgreSQL database dump
--

\restrict s2gHBHAw65faixUAXpwAqfamTRxg3E8AucsGmOFij9c6CuiLQtQ9GaDIMOHxc4Z

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: defaultdb; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE defaultdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE defaultdb OWNER TO root;

\unrestrict s2gHBHAw65faixUAXpwAqfamTRxg3E8AucsGmOFij9c6CuiLQtQ9GaDIMOHxc4Z
\connect defaultdb
\restrict s2gHBHAw65faixUAXpwAqfamTRxg3E8AucsGmOFij9c6CuiLQtQ9GaDIMOHxc4Z

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict s2gHBHAw65faixUAXpwAqfamTRxg3E8AucsGmOFij9c6CuiLQtQ9GaDIMOHxc4Z

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict q1Z2VM8tdRV68wgqUkA4WAeKtDjt5SlSzigPmeY9HEIpdrV4Ev0RAJQklMIjxxA

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict q1Z2VM8tdRV68wgqUkA4WAeKtDjt5SlSzigPmeY9HEIpdrV4Ev0RAJQklMIjxxA

--
-- PostgreSQL database cluster dump complete
--

