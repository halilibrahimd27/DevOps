--
-- PostgreSQL database cluster dump
--

\restrict sdATmGZrjDVIgBlBhWGsg0Gn4VDGOT2VlGxM2csBlm1NHdMp9y2rdq80wcnAqN4

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE root;
ALTER ROLE root WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:smSz9m7GQHAkekLc08sc8w==$EwiwtvXWtqLDY5h1VzXVNxOfit5HhggfHub6gadmqdw=:ZU8I6cmx95++qWsCqyVAUEqrReH8KL9MuyvMUyyRNlk=';

--
-- User Configurations
--








\unrestrict sdATmGZrjDVIgBlBhWGsg0Gn4VDGOT2VlGxM2csBlm1NHdMp9y2rdq80wcnAqN4

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict 4RBIOs2a21PR8r8WFTYU23pXCu2FKBJmXfCSWd4CUYcDK5uYFTRoHMmd1LxFMMr

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict 4RBIOs2a21PR8r8WFTYU23pXCu2FKBJmXfCSWd4CUYcDK5uYFTRoHMmd1LxFMMr

--
-- Database "defaultdb" dump
--

--
-- PostgreSQL database dump
--

\restrict DNvQnu1pxPL3yumd4xLFIt6IKKkd2MidwuspPd0krGPVIC4hnVfFDHtTd74yozR

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: defaultdb; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE defaultdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE defaultdb OWNER TO root;

\unrestrict DNvQnu1pxPL3yumd4xLFIt6IKKkd2MidwuspPd0krGPVIC4hnVfFDHtTd74yozR
\connect defaultdb
\restrict DNvQnu1pxPL3yumd4xLFIt6IKKkd2MidwuspPd0krGPVIC4hnVfFDHtTd74yozR

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict DNvQnu1pxPL3yumd4xLFIt6IKKkd2MidwuspPd0krGPVIC4hnVfFDHtTd74yozR

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict Kit9L0g7HTP0fazYzbUeJ3AbDIsQp3pfXUa3P9bmS6GYt7mIuikRkq5OmpXri0i

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict Kit9L0g7HTP0fazYzbUeJ3AbDIsQp3pfXUa3P9bmS6GYt7mIuikRkq5OmpXri0i

--
-- PostgreSQL database cluster dump complete
--

