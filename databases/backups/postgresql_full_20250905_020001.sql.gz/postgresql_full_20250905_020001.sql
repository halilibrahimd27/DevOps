--
-- PostgreSQL database cluster dump
--

\restrict wDFnJOtjyYSOuMXg53tuQdhWkxzH4RkoU3Diwe7gCxhUv4e1xnJGZRMy9H2WTU5

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE root;
ALTER ROLE root WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:smSz9m7GQHAkekLc08sc8w==$EwiwtvXWtqLDY5h1VzXVNxOfit5HhggfHub6gadmqdw=:ZU8I6cmx95++qWsCqyVAUEqrReH8KL9MuyvMUyyRNlk=';

--
-- User Configurations
--








\unrestrict wDFnJOtjyYSOuMXg53tuQdhWkxzH4RkoU3Diwe7gCxhUv4e1xnJGZRMy9H2WTU5

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict DCXlMw1Hj4rIOcgAhAFOW9KvzTmi8i8PcXnZojJRQBb7NAfoUjJWISIrNVIFyzS

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict DCXlMw1Hj4rIOcgAhAFOW9KvzTmi8i8PcXnZojJRQBb7NAfoUjJWISIrNVIFyzS

--
-- Database "defaultdb" dump
--

--
-- PostgreSQL database dump
--

\restrict o6f7x9XuB7RGnMjQeedLVZpYEc7R3vqsd1ZhWMLk1AeuUft650VJWGt9ohX4ZA9

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: defaultdb; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE defaultdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE defaultdb OWNER TO root;

\unrestrict o6f7x9XuB7RGnMjQeedLVZpYEc7R3vqsd1ZhWMLk1AeuUft650VJWGt9ohX4ZA9
\connect defaultdb
\restrict o6f7x9XuB7RGnMjQeedLVZpYEc7R3vqsd1ZhWMLk1AeuUft650VJWGt9ohX4ZA9

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict o6f7x9XuB7RGnMjQeedLVZpYEc7R3vqsd1ZhWMLk1AeuUft650VJWGt9ohX4ZA9

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict ElnQm6anuWPfThanTIBbBSQEfDR0VtKFrUYj5s6Zx59YzcVCP5HEu40mkFRw3gW

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict ElnQm6anuWPfThanTIBbBSQEfDR0VtKFrUYj5s6Zx59YzcVCP5HEu40mkFRw3gW

--
-- PostgreSQL database cluster dump complete
--

