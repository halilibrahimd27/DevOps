--
-- PostgreSQL database cluster dump
--

\restrict Nog7bq6pIO5iJcgLuD8R1dlzTvO6AXB7uJQqC4i393hojgjT8bniygxQVCsfieY

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE root;
ALTER ROLE root WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:smSz9m7GQHAkekLc08sc8w==$EwiwtvXWtqLDY5h1VzXVNxOfit5HhggfHub6gadmqdw=:ZU8I6cmx95++qWsCqyVAUEqrReH8KL9MuyvMUyyRNlk=';

--
-- User Configurations
--








\unrestrict Nog7bq6pIO5iJcgLuD8R1dlzTvO6AXB7uJQqC4i393hojgjT8bniygxQVCsfieY

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict 1JC4kI0DNSXOlge3FsjKjx27bKFBLpdlA1e4r1QhUMgr9AJtFtEHqSO8HWlxyLl

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict 1JC4kI0DNSXOlge3FsjKjx27bKFBLpdlA1e4r1QhUMgr9AJtFtEHqSO8HWlxyLl

--
-- Database "defaultdb" dump
--

--
-- PostgreSQL database dump
--

\restrict SwD5lCYf4shp2lVQJa6hJGhhA5AbOFfrYTJQZnTngHDecp8HdA7fsbd1JHUebzM

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: defaultdb; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE defaultdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE defaultdb OWNER TO root;

\unrestrict SwD5lCYf4shp2lVQJa6hJGhhA5AbOFfrYTJQZnTngHDecp8HdA7fsbd1JHUebzM
\connect defaultdb
\restrict SwD5lCYf4shp2lVQJa6hJGhhA5AbOFfrYTJQZnTngHDecp8HdA7fsbd1JHUebzM

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict SwD5lCYf4shp2lVQJa6hJGhhA5AbOFfrYTJQZnTngHDecp8HdA7fsbd1JHUebzM

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict lMbw6Wa6AaFgFncXDBJ5GhthCQ5gO6r1qSWhLlxE5UrPGfWlTSgRcGlc7hzW3vf

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict lMbw6Wa6AaFgFncXDBJ5GhthCQ5gO6r1qSWhLlxE5UrPGfWlTSgRcGlc7hzW3vf

--
-- PostgreSQL database cluster dump complete
--

