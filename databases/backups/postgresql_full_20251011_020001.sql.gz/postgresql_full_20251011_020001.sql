--
-- PostgreSQL database cluster dump
--

\restrict AW1CvggHicyL9dcjFnOkLE9WPgRUvrd0tjfUDMkKHnN5q86wOA1FoQ9tOuVSkfV

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE root;
ALTER ROLE root WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:roEld3x8TuQ8bSi9KhPKJg==$lbYxIGb9YGRy9bON1ZkblBILRYXGVLqsvvDpufP9gKs=:4x/aalULpsoxQH/UnzLnuAPdiu2pm/yFx8m47dvzm9A=';

--
-- User Configurations
--








\unrestrict AW1CvggHicyL9dcjFnOkLE9WPgRUvrd0tjfUDMkKHnN5q86wOA1FoQ9tOuVSkfV

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict rsT3u11YuxnVpaTxVwE50RwQndlafdSCJSnbTQaHSZUhYlCkwdkOu5eifWddHPJ

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict rsT3u11YuxnVpaTxVwE50RwQndlafdSCJSnbTQaHSZUhYlCkwdkOu5eifWddHPJ

--
-- Database "defaultdb" dump
--

--
-- PostgreSQL database dump
--

\restrict KVQT0BkQNpo8PLqN5FFRFpIAeO1kr85Ne4qz0cywVj17Itmp63OfRmE3cZzdaXy

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: defaultdb; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE defaultdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE defaultdb OWNER TO root;

\unrestrict KVQT0BkQNpo8PLqN5FFRFpIAeO1kr85Ne4qz0cywVj17Itmp63OfRmE3cZzdaXy
\connect defaultdb
\restrict KVQT0BkQNpo8PLqN5FFRFpIAeO1kr85Ne4qz0cywVj17Itmp63OfRmE3cZzdaXy

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict KVQT0BkQNpo8PLqN5FFRFpIAeO1kr85Ne4qz0cywVj17Itmp63OfRmE3cZzdaXy

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict mGpYsaDIGQhTZkgHjPkGbggjwFsXMZYqJTV5s0u88ZIrCkLzoUhHJrJBfsjNnTm

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict mGpYsaDIGQhTZkgHjPkGbggjwFsXMZYqJTV5s0u88ZIrCkLzoUhHJrJBfsjNnTm

--
-- PostgreSQL database cluster dump complete
--

