--
-- PostgreSQL database cluster dump
--

\restrict YM10Uda8sz18L84bYb6eGb0YjWR1KNXZ9ACMqNgk5CSmdw09WN2siZEb8j167lF

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE root;
ALTER ROLE root WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:roEld3x8TuQ8bSi9KhPKJg==$lbYxIGb9YGRy9bON1ZkblBILRYXGVLqsvvDpufP9gKs=:4x/aalULpsoxQH/UnzLnuAPdiu2pm/yFx8m47dvzm9A=';

--
-- User Configurations
--








\unrestrict YM10Uda8sz18L84bYb6eGb0YjWR1KNXZ9ACMqNgk5CSmdw09WN2siZEb8j167lF

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict o8o14eU3NOFL5eb4CLgdFenBoJHriW4o0uTgetYBfCxTv41sbbvGTltti0lw4Ku

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict o8o14eU3NOFL5eb4CLgdFenBoJHriW4o0uTgetYBfCxTv41sbbvGTltti0lw4Ku

--
-- Database "defaultdb" dump
--

--
-- PostgreSQL database dump
--

\restrict jjByTLzV4emfl3t7qri3p2yVuCyQGfKPKihxoiTqFDTosJp79slVEumBjHXjag3

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: defaultdb; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE defaultdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE defaultdb OWNER TO root;

\unrestrict jjByTLzV4emfl3t7qri3p2yVuCyQGfKPKihxoiTqFDTosJp79slVEumBjHXjag3
\connect defaultdb
\restrict jjByTLzV4emfl3t7qri3p2yVuCyQGfKPKihxoiTqFDTosJp79slVEumBjHXjag3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict jjByTLzV4emfl3t7qri3p2yVuCyQGfKPKihxoiTqFDTosJp79slVEumBjHXjag3

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict QcQ8GTxbBigYehru8q49dqhaKgqqjsD25W0HPwE2ieHXfQGO7sw6Ul8lXgSbAlG

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict QcQ8GTxbBigYehru8q49dqhaKgqqjsD25W0HPwE2ieHXfQGO7sw6Ul8lXgSbAlG

--
-- PostgreSQL database cluster dump complete
--

