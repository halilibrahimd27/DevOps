--
-- PostgreSQL database cluster dump
--

\restrict WZqsCfYINXJaB78AWhv3dKTw5BnV3xjtTLOQmUZjT2xJlCiBLPEvVXTn4oElNDa

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE root;
ALTER ROLE root WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:smSz9m7GQHAkekLc08sc8w==$EwiwtvXWtqLDY5h1VzXVNxOfit5HhggfHub6gadmqdw=:ZU8I6cmx95++qWsCqyVAUEqrReH8KL9MuyvMUyyRNlk=';

--
-- User Configurations
--








\unrestrict WZqsCfYINXJaB78AWhv3dKTw5BnV3xjtTLOQmUZjT2xJlCiBLPEvVXTn4oElNDa

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict PoWHcGhqZbWeJWeJiavyC9s0jdB0hF1lb0UAi1g7Ww9aQigQIGwSYAw8zrwOkVL

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict PoWHcGhqZbWeJWeJiavyC9s0jdB0hF1lb0UAi1g7Ww9aQigQIGwSYAw8zrwOkVL

--
-- Database "defaultdb" dump
--

--
-- PostgreSQL database dump
--

\restrict 0pQQk6g0WW7ku7fcYQDIf2Ps0ygc3rtw5yGmeSgC4SxFYqahqVLIhR1b1nTD02j

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: defaultdb; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE defaultdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE defaultdb OWNER TO root;

\unrestrict 0pQQk6g0WW7ku7fcYQDIf2Ps0ygc3rtw5yGmeSgC4SxFYqahqVLIhR1b1nTD02j
\connect defaultdb
\restrict 0pQQk6g0WW7ku7fcYQDIf2Ps0ygc3rtw5yGmeSgC4SxFYqahqVLIhR1b1nTD02j

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict 0pQQk6g0WW7ku7fcYQDIf2Ps0ygc3rtw5yGmeSgC4SxFYqahqVLIhR1b1nTD02j

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict cM5ePuJTTObdXITKq5y5R9lTnzTDf4qf0LyBVsUz8eAQQLrSy0gHTrsHDmiJrBU

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict cM5ePuJTTObdXITKq5y5R9lTnzTDf4qf0LyBVsUz8eAQQLrSy0gHTrsHDmiJrBU

--
-- PostgreSQL database cluster dump complete
--

