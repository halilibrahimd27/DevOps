--
-- PostgreSQL database cluster dump
--

\restrict StHmfS99fx9cOWx6Nca4cFfKkK27JIzEKcHEGwrsCwGMACEIl8saa89bvtyd9Lg

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE root;
ALTER ROLE root WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:smSz9m7GQHAkekLc08sc8w==$EwiwtvXWtqLDY5h1VzXVNxOfit5HhggfHub6gadmqdw=:ZU8I6cmx95++qWsCqyVAUEqrReH8KL9MuyvMUyyRNlk=';

--
-- User Configurations
--








\unrestrict StHmfS99fx9cOWx6Nca4cFfKkK27JIzEKcHEGwrsCwGMACEIl8saa89bvtyd9Lg

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict 5ezt9U7ftcob80PlqARGvBY7Lku6zwAKcbR9nd7wPJBEUwU2QG657WOCKsoclaV

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict 5ezt9U7ftcob80PlqARGvBY7Lku6zwAKcbR9nd7wPJBEUwU2QG657WOCKsoclaV

--
-- Database "defaultdb" dump
--

--
-- PostgreSQL database dump
--

\restrict ofsAtpL1EnipDyScUO2ad6L93bxyBrfdHcPbhRN3nF9Ir0IPNgtQea6E82UKdNz

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: defaultdb; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE defaultdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE defaultdb OWNER TO root;

\unrestrict ofsAtpL1EnipDyScUO2ad6L93bxyBrfdHcPbhRN3nF9Ir0IPNgtQea6E82UKdNz
\connect defaultdb
\restrict ofsAtpL1EnipDyScUO2ad6L93bxyBrfdHcPbhRN3nF9Ir0IPNgtQea6E82UKdNz

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict ofsAtpL1EnipDyScUO2ad6L93bxyBrfdHcPbhRN3nF9Ir0IPNgtQea6E82UKdNz

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict z75n693FHlTtcN5foaw9qUr8OyEfx5YyYT1lYblc0q7JYt5bnticdg7SK497qPw

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict z75n693FHlTtcN5foaw9qUr8OyEfx5YyYT1lYblc0q7JYt5bnticdg7SK497qPw

--
-- PostgreSQL database cluster dump complete
--

