--
-- PostgreSQL database cluster dump
--

\restrict BdAJyB9rWZJoMuy6e7u7mLi87VyCCiVhb07hAjxXLwjB7c6BAtUbeAlnDWvR5vK

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE root;
ALTER ROLE root WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:FRDY3uA9jHGPV4dxrEgfDg==$dphagvJM/vpAO5cVZHoV4o96pTTnaBCrzsG8jRUWyuU=:+WLVdfWc47CDceqxRG5SLirDwF5eLPddis6YQg52TzI=';

--
-- User Configurations
--








\unrestrict BdAJyB9rWZJoMuy6e7u7mLi87VyCCiVhb07hAjxXLwjB7c6BAtUbeAlnDWvR5vK

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict T2nyx1qEbEcDUICRn04NOFYYYXdokovZOf2rpewth1aikGtcXhKuiuqBri3yNZI

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict T2nyx1qEbEcDUICRn04NOFYYYXdokovZOf2rpewth1aikGtcXhKuiuqBri3yNZI

--
-- Database "defaultdb" dump
--

--
-- PostgreSQL database dump
--

\restrict ylVKK4yUf3miBEHjgwAu201MTvqcvUFVugUVK4o5W0w7ZWfnDCra0pBBEawt9vM

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: defaultdb; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE defaultdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE defaultdb OWNER TO root;

\unrestrict ylVKK4yUf3miBEHjgwAu201MTvqcvUFVugUVK4o5W0w7ZWfnDCra0pBBEawt9vM
\connect defaultdb
\restrict ylVKK4yUf3miBEHjgwAu201MTvqcvUFVugUVK4o5W0w7ZWfnDCra0pBBEawt9vM

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict ylVKK4yUf3miBEHjgwAu201MTvqcvUFVugUVK4o5W0w7ZWfnDCra0pBBEawt9vM

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict tuRtpIXo56mcQWmhHZI8KWahKKGPrMSmrkKbl8Upv3yiRWcr6GuIAY2HcCsRC4R

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict tuRtpIXo56mcQWmhHZI8KWahKKGPrMSmrkKbl8Upv3yiRWcr6GuIAY2HcCsRC4R

--
-- PostgreSQL database cluster dump complete
--

