--
-- PostgreSQL database cluster dump
--

\restrict fYpblo3VkWyXjYnOXSdDUduvoj0b0t21kTvdVGUaAFZK7Sqj6EDHdHVkQt3p1ea

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE root;
ALTER ROLE root WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:roEld3x8TuQ8bSi9KhPKJg==$lbYxIGb9YGRy9bON1ZkblBILRYXGVLqsvvDpufP9gKs=:4x/aalULpsoxQH/UnzLnuAPdiu2pm/yFx8m47dvzm9A=';

--
-- User Configurations
--








\unrestrict fYpblo3VkWyXjYnOXSdDUduvoj0b0t21kTvdVGUaAFZK7Sqj6EDHdHVkQt3p1ea

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict m74wtGKYQHsKwm4iR5a9Ld8gNDgVJJ8qnSuquK340v8zGcKfZooY4oTjwGGBzQ8

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict m74wtGKYQHsKwm4iR5a9Ld8gNDgVJJ8qnSuquK340v8zGcKfZooY4oTjwGGBzQ8

--
-- Database "defaultdb" dump
--

--
-- PostgreSQL database dump
--

\restrict Wwd9lpKe9FCseh6hrZZZInfazMfDu0FnheLKpZZVg6YRJQXcLhp5PSSHRIlsmJC

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: defaultdb; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE defaultdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE defaultdb OWNER TO root;

\unrestrict Wwd9lpKe9FCseh6hrZZZInfazMfDu0FnheLKpZZVg6YRJQXcLhp5PSSHRIlsmJC
\connect defaultdb
\restrict Wwd9lpKe9FCseh6hrZZZInfazMfDu0FnheLKpZZVg6YRJQXcLhp5PSSHRIlsmJC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict Wwd9lpKe9FCseh6hrZZZInfazMfDu0FnheLKpZZVg6YRJQXcLhp5PSSHRIlsmJC

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict v2iaMOpAVT6KH6vtVv11VHL7Ex4gB4pLyERgu4Sr1ckohTFODL6YMID5idHkves

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict v2iaMOpAVT6KH6vtVv11VHL7Ex4gB4pLyERgu4Sr1ckohTFODL6YMID5idHkves

--
-- PostgreSQL database cluster dump complete
--

