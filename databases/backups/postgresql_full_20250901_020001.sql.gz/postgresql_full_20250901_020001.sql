--
-- PostgreSQL database cluster dump
--

\restrict g8ocH5kqzeQgzqmLbuICFfrZpTQ4KTj8shFRX9NYZHMR6xZcdDbKcbpFP4iiyeJ

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE root;
ALTER ROLE root WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:smSz9m7GQHAkekLc08sc8w==$EwiwtvXWtqLDY5h1VzXVNxOfit5HhggfHub6gadmqdw=:ZU8I6cmx95++qWsCqyVAUEqrReH8KL9MuyvMUyyRNlk=';

--
-- User Configurations
--








\unrestrict g8ocH5kqzeQgzqmLbuICFfrZpTQ4KTj8shFRX9NYZHMR6xZcdDbKcbpFP4iiyeJ

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict GgFKw6OqokesOFwrmtvAZqhsNwqMduSseXCfR5JlPir43RWiXySo0Lm2yroEvp3

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict GgFKw6OqokesOFwrmtvAZqhsNwqMduSseXCfR5JlPir43RWiXySo0Lm2yroEvp3

--
-- Database "defaultdb" dump
--

--
-- PostgreSQL database dump
--

\restrict ylfUMHBTm55aJV6Ex8u10ws07kglBNTvVuQAqdcaNvMCPnXBxbfyxNin1ucROeg

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: defaultdb; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE defaultdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE defaultdb OWNER TO root;

\unrestrict ylfUMHBTm55aJV6Ex8u10ws07kglBNTvVuQAqdcaNvMCPnXBxbfyxNin1ucROeg
\connect defaultdb
\restrict ylfUMHBTm55aJV6Ex8u10ws07kglBNTvVuQAqdcaNvMCPnXBxbfyxNin1ucROeg

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict ylfUMHBTm55aJV6Ex8u10ws07kglBNTvVuQAqdcaNvMCPnXBxbfyxNin1ucROeg

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict Ljm3V3gF9eDOD2Bsuv6DeSn7zkvpj46skVE7yQpa3B1yCcDgO20hju7uyF333yd

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict Ljm3V3gF9eDOD2Bsuv6DeSn7zkvpj46skVE7yQpa3B1yCcDgO20hju7uyF333yd

--
-- PostgreSQL database cluster dump complete
--

